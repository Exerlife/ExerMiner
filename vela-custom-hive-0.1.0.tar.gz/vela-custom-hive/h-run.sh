#!/usr/bin/env bash
# Vela Custom Miner — HiveOS launcher (AriaPool JSON-RPC, not Stratum).
set -Eeuo pipefail
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$SCRIPT_DIR"
. ./h-manifest.conf

mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
exec > >(tee -i --append "${CUSTOM_LOG_BASENAME}.log") 2>&1

log() { printf '%s %s\n' "$(date '+%F %T')" "$*"; }
fail() { log "ERROR: $*"; exit 1; }

[[ -f "$CUSTOM_CONFIG_FILENAME" ]] || fail "No flight-sheet configuration at $CUSTOM_CONFIG_FILENAME; save the flight sheet again."

# Read JSON safely and build an authenticated RPC URL without printing the wallet or password.
eval "$(python3 - "$CUSTOM_CONFIG_FILENAME" <<'PY'
import json, shlex, sys
from urllib.parse import quote, urlsplit, urlunsplit
with open(sys.argv[1], encoding='utf-8') as f:
    c=json.load(f)
pool=c.get('pool_url','').strip()
login=c.get('login','').strip()
password=c.get('password','x')
extra=c.get('extra','')
if not pool or not login.startswith('vela1'):
    raise SystemExit('invalid pool URL or VELA wallet template')
if '://' not in pool:
    pool='http://' + pool
p=urlsplit(pool)
if p.scheme not in ('http','https') or not p.hostname or not p.port:
    raise SystemExit('AriaPool URL must be http(s)://host:port')
if p.username or p.password:
    raise SystemExit('Put only the pool host in Pool URL; wallet/password belong in HiveOS Wallet/Pass fields')
netloc=f"{quote(login, safe='')}:{quote(password, safe='')}@{p.hostname}:{p.port}"
if p.hostname and ':' in p.hostname and not p.hostname.startswith('['):
    netloc=f"{quote(login, safe='')}:{quote(password, safe='')}@[{p.hostname}]:{p.port}"
rpc=urlunsplit((p.scheme, netloc, p.path or '/', p.query, ''))
wallet=login.split('.',1)[0]
for k,v in {'POOL_RPC_URL':rpc,'WALLET_ADDRESS':wallet,'EXTRA_ARGS':extra}.items():
    print(f'export {k}={shlex.quote(v)}')
PY
)" || fail "Could not parse flight-sheet configuration."

STATE_DIR=/hive-config/vela-custom-hive
MODEL_DIR="$STATE_DIR/models"
VENV="$STATE_DIR/venv"
MODEL="$MODEL_DIR/sd-turbo-int.poisd"
MODEL_SHA=ba38ab96b3398e22ea631d8a457350f91833e57463199d063663308513651f36
MODEL_URLS=(
  "https://huggingface.co/valereseach/vela-sd-turbo-int-v2/resolve/main/sd-turbo-int.poisd"
  "https://dl.ariabrain.com/vela-dl/sd-turbo-int.poisd"
)
mkdir -p "$MODEL_DIR" "$STATE_DIR/logs"

# Model is large; cache it on the persistent HiveOS config volume and verify the exact official digest.
model_ok=0
if [[ -f "$MODEL" ]] && [[ "$(sha256sum "$MODEL" | awk '{print $1}')" == "$MODEL_SHA" ]]; then
  model_ok=1
fi
if [[ "$model_ok" != 1 ]]; then
  rm -f "$MODEL_DIR/sd-turbo-int.poisd.ok"
  for url in "${MODEL_URLS[@]}"; do
    log "Downloading the official Vela PoI v2 model from $url"
    part="$MODEL.part"
    if curl -fL --retry 5 --retry-delay 3 --connect-timeout 20 -C - -o "$part" "$url"; then
      got=$(sha256sum "$part" | awk '{print $1}')
      if [[ "$got" == "$MODEL_SHA" ]]; then
        mv -f "$part" "$MODEL"
        model_ok=1
        break
      fi
      log "Model SHA-256 mismatch from this source; trying the mirror. actual=$got"
      rm -f "$part"
    else
      log "Download failed from this source; trying the mirror."
    fi
  done
fi
[[ "$model_ok" == 1 ]] || fail "Could not download/verify sd-turbo-int.poisd. Expected SHA-256 $MODEL_SHA."
printf '%s  %s\n' "$MODEL_SHA" "$MODEL" | sha256sum -c - || fail "Model integrity check failed."

# One persistent venv; CUDA-enabled PyTorch is downloaded on the first run only.
PYTHON_BIN=$(command -v python3 || true)
[[ -n "$PYTHON_BIN" ]] || fail "python3 is not installed on this HiveOS image."
if [[ ! -x "$VENV/bin/python" ]]; then
  log "Creating persistent Python environment at $VENV"
  "$PYTHON_BIN" -m venv "$VENV" || fail "python3-venv is missing. Install the HiveOS python3-venv package and restart the miner."
fi
VPY="$VENV/bin/python"
DEPS_MARKER="$STATE_DIR/dependencies-cu128-torch271.ok"
if [[ ! -f "$DEPS_MARKER" ]] || ! "$VPY" -c 'import torch, numpy, cryptography; assert torch.cuda.is_available()' >/dev/null 2>&1; then
  log "Installing CUDA PyTorch 2.7.1 (cu128), NumPy and cryptography; first run downloads the runtime wheels."
  "$VPY" -m pip install --upgrade pip || fail "pip upgrade failed inside the Vela virtualenv."
  "$VPY" -m pip install --index-url https://download.pytorch.org/whl/cu128 'torch==2.7.1' || fail "CUDA PyTorch installation failed. Check network access and Python compatibility."
  "$VPY" -m pip install 'numpy==1.26.4' 'cryptography>=42,<47' || fail "Python dependencies failed to install."
  "$VPY" - <<'PY' || fail "PyTorch CUDA self-check failed."
import torch, numpy, cryptography
print('torch=', torch.__version__, 'torch_cuda=', torch.version.cuda,
      'cuda_available=', torch.cuda.is_available(), 'gpu_count=', torch.cuda.device_count())
if not torch.cuda.is_available() or torch.cuda.device_count() < 1:
    raise SystemExit('CUDA is unavailable: refusing CPU mining')
for i in range(torch.cuda.device_count()):
    print('GPU', i, torch.cuda.get_device_name(i), 'capability', torch.cuda.get_device_capability(i))
PY
  touch "$DEPS_MARKER"
fi

# Never silently fall back to CPU on a mining rig.
"$VPY" - <<'PY' || fail "No usable CUDA GPU was detected; refusing to mine on CPU."
import torch
if not torch.cuda.is_available() or torch.cuda.device_count() < 1:
    raise SystemExit(1)
PY
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export PYTHONUNBUFFERED=1
LOG_FILE="$STATE_DIR/logs/vela-miner.log"

# Defaults favor safe VRAM use on 8 GB RTX 3070 cards. Extra config can override these options.
read -r -a extra_array <<< "${EXTRA_ARGS:-}"
log "Starting Vela PoI v2 pool miner; endpoint=$(python3 - "$POOL_RPC_URL" <<'PY'
import sys
from urllib.parse import urlsplit
p=urlsplit(sys.argv[1]); print(f'{p.scheme}://{p.hostname}:{p.port}')
PY
) wallet=${WALLET_ADDRESS:0:10}..."
log "Default tuning: one CUDA stream per GPU; auto batch 1/2/4/8 with exact reference checks. Add --lanes 2 in Extra config only after a safe comparison."
exec "$VPY" -u "$SCRIPT_DIR/legacy-python/sd_miner.py" \
  --rpc "$POOL_RPC_URL" \
  --address "$WALLET_ADDRESS" \
  --model "$MODEL" \
  --devices auto \
  --lanes 1 \
  --auto-batch --max-batch 8 \
  --blocks 0 \
  --tip-poll 0.5 \
  --canary-interval 120 \
  --status-interval 30 \
  --log-file "$LOG_FILE" \
  "${extra_array[@]}"
