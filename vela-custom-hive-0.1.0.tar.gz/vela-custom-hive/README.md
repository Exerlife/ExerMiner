# Vela Custom Miner for HiveOS — AriaPool

This is a HiveOS Custom Miner package for the PoI v2 CUDA miner in `legacy-python/`.
It connects to **AriaPool through its Vela JSON-RPC pool endpoint**. It is not a Stratum client.
SuprNova's `vela.suprnova.cc:7601/7604` Stratum protocol is not supported by this miner package.

## Build the HiveOS archive

From the repository root:

```bash
./scripts/package-hiveos.sh
```

The script creates `dist/vela-custom-hive-0.1.0.tar.gz` and its SHA-256 file.
Upload the `.tar.gz` as a GitHub Release asset. Use the *direct asset URL* in the Flight Sheet.

## Flight Sheet

- Coin: `Custom`, symbol `VELA`
- Wallet: your mainnet address beginning `vela1`
- Pool: `Configure in miner`
- Miner: `Custom` → `vela-custom-hive`
- Installation URL: direct GitHub Release asset URL for `vela-custom-hive-0.1.0.tar.gz`
- Hash algorithm: `vela`
- Wallet and worker template: `%WAL%.%WORKER_NAME%`
- Pool URL: `http://159.69.194.46:3349` (AriaPool Vela JSON-RPC)
- Password: `x`
- Extra config arguments: leave empty for the safe initial configuration

On the first start, the wrapper downloads and SHA-256 verifies the 1.19 GB model and installs a
CUDA-enabled PyTorch environment under `/hive-config/vela-custom-hive/`. Both are cached across
miner updates. NVIDIA driver R570 or newer is required; R580+ is recommended by the current pool
setup guide. The wrapper refuses to mine if PyTorch cannot see CUDA GPUs (no CPU fallback).

## Runtime defaults

- All visible NVIDIA GPUs, in PCI bus order.
- One CUDA stream per GPU initially.
- Per-GPU adaptive batch test across 1, 2, 4 and 8; each candidate batch is checked against the
  independent V2 reference before selection.
- Periodic per-stream consensus canaries and independent candidate re-computation before submission.
- Rotating detailed log at `/hive-config/vela-custom-hive/logs/vela-miner.log`.
- HiveOS log at `/var/log/miner/vela-custom-hive/vela-custom-hive.log`.

After verifying a stable baseline, `--lanes 2` can be added to Extra config for an A/B test. It is
not enabled by default because this PyTorch engine shares weights and buffers differently from
FFGV's CUDA engine; FFGV's measured +5.4% RTX 3070 lane gain must not be assumed to transfer.

## Pool compatibility

AriaPool publishes a JSON-RPC endpoint on port 3349 and documents use of the unmodified Vela
`sd_miner.py` against that interface. The wrapper forms HTTP Basic authentication from the wallet
and password fields, and passes the payout address separately to the miner. A pool URL with only
`host:port` or `http(s)://host:port` is accepted.

SuprNova is Stratum, not JSON-RPC. Do not put `vela.suprnova.cc:7601` or `:7604` into this
package's Pool URL; use a Stratum-capable miner for those endpoints.

## Logs and stats

The log records job height, parent hash, compact bits, full target, model hash, Merkle root,
nonce, full block hash, `hashPoI`, x0 SHA-256, attempts, aggregate and per-GPU `inf/s`, canary
results, final reference-check results, and the JSON-RPC submission response. HiveOS stats are
parsed from the structured log and include per-GPU inference rate, temperature, fan, and
submission accept/reject counters.

## Important limitations

This is a research/custom build and has not been benchmarked on the user's physical RTX 3070 rig.
The CUDA batch/stream correctness and throughput still require a real HiveOS run. The package is
for the current PoI v2 JSON-RPC pool path; it does not provide SuprNova Stratum or a v3/VIR model
bundle. Never assume a speed improvement until compared on the same cards, clocks, power limit,
and pool conditions.
